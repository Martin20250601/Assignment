#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "storage_mgr.h"
#include "dberror.h"

void initStorageManager(void) {
    // 初始化存储管理器，目前不需要特殊操作
}

RC createPageFile(char *fileName) {
    FILE *file;
    char *emptyPage;
    
    // 创建文件
    file = fopen(fileName, "wb");
    if (file == NULL) {
        return RC_FILE_NOT_FOUND;
    }
    
    // 创建一个空页面
    emptyPage = (char *)calloc(PAGE_SIZE, sizeof(char));
    if (emptyPage == NULL) {
        fclose(file);
        return RC_WRITE_FAILED;
    }
    
    // 写入第一个页面
    if (fwrite(emptyPage, sizeof(char), PAGE_SIZE, file) != PAGE_SIZE) {
        free(emptyPage);
        fclose(file);
        return RC_WRITE_FAILED;
    }
    
    free(emptyPage);
    fclose(file);
    return RC_OK;
}

RC openPageFile(char *fileName, SM_FileHandle *fHandle) {
    FILE *file;
    struct stat fileInfo;
    
    // 检查文件是否存在
    if (stat(fileName, &fileInfo) != 0) {
        return RC_FILE_NOT_FOUND;
    }
    
    // 打开文件
    file = fopen(fileName, "rb+");
    if (file == NULL) {
        return RC_FILE_NOT_FOUND;
    }
    
    // 初始化文件句柄
    fHandle->fileName = (char *)malloc(strlen(fileName) + 1);
    strcpy(fHandle->fileName, fileName);
    fHandle->totalNumPages = fileInfo.st_size / PAGE_SIZE;
    fHandle->curPagePos = 0;
    fHandle->mgmtInfo = file;
    
    return RC_OK;
}

RC closePageFile(SM_FileHandle *fHandle) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    // 关闭文件
    if (fclose((FILE *)fHandle->mgmtInfo) != 0) {
        return RC_WRITE_FAILED;
    }
    
    // 释放内存
    free(fHandle->fileName);
    fHandle->fileName = NULL;
    fHandle->mgmtInfo = NULL;
    
    return RC_OK;
}

RC destroyPageFile(char *fileName) {
    if (remove(fileName) != 0) {
        return RC_FILE_NOT_FOUND;
    }
    return RC_OK;
}

RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
    FILE *file;
    
    if (fHandle == NULL || fHandle->mgmtInfo == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    if (pageNum < 0 || pageNum >= fHandle->totalNumPages) {
        return RC_READ_NON_EXISTING_PAGE;
    }
    
    file = (FILE *)fHandle->mgmtInfo;
    
    // 定位到指定页面
    if (fseek(file, pageNum * PAGE_SIZE, SEEK_SET) != 0) {
        return RC_READ_NON_EXISTING_PAGE;
    }
    
    // 读取页面
    if (fread(memPage, sizeof(char), PAGE_SIZE, file) != PAGE_SIZE) {
        return RC_READ_NON_EXISTING_PAGE;
    }
    
    fHandle->curPagePos = pageNum;
    return RC_OK;
}

int getBlockPos(SM_FileHandle *fHandle) {
    if (fHandle == NULL) {
        return -1;
    }
    return fHandle->curPagePos;
}

RC readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    return readBlock(0, fHandle, memPage);
}

RC readPreviousBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    return readBlock(fHandle->curPagePos - 1, fHandle, memPage);
}

RC readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    return readBlock(fHandle->curPagePos, fHandle, memPage);
}

RC readNextBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    return readBlock(fHandle->curPagePos + 1, fHandle, memPage);
}

RC readLastBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    return readBlock(fHandle->totalNumPages - 1, fHandle, memPage);
}

RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
    FILE *file;
    
    if (fHandle == NULL || fHandle->mgmtInfo == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    if (pageNum < 0) {
        return RC_WRITE_FAILED;
    }
    
    file = (FILE *)fHandle->mgmtInfo;
    
    // 如果页面超出当前文件大小，需要扩展文件
    if (pageNum >= fHandle->totalNumPages) {
        if (ensureCapacity(pageNum + 1, fHandle) != RC_OK) {
            return RC_WRITE_FAILED;
        }
    }
    
    // 定位到指定页面
    if (fseek(file, pageNum * PAGE_SIZE, SEEK_SET) != 0) {
        return RC_WRITE_FAILED;
    }
    
    // 写入页面
    if (fwrite(memPage, sizeof(char), PAGE_SIZE, file) != PAGE_SIZE) {
        return RC_WRITE_FAILED;
    }
    
    fHandle->curPagePos = pageNum;
    fflush(file);
    return RC_OK;
}

RC writeCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    return writeBlock(fHandle->curPagePos, fHandle, memPage);
}

RC appendEmptyBlock(SM_FileHandle *fHandle) {
    char *emptyPage;
    FILE *file;

    if (fHandle == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    emptyPage = (char *)calloc(PAGE_SIZE, sizeof(char));
    if (emptyPage == NULL) {
        return RC_WRITE_FAILED;
    }

    file = (FILE *)fHandle->mgmtInfo;

    // 定位到文件末尾
    if (fseek(file, fHandle->totalNumPages * PAGE_SIZE, SEEK_SET) != 0) {
        free(emptyPage);
        return RC_WRITE_FAILED;
    }

    // 写入空页面
    if (fwrite(emptyPage, sizeof(char), PAGE_SIZE, file) != PAGE_SIZE) {
        free(emptyPage);
        return RC_WRITE_FAILED;
    }

    fflush(file);
    fHandle->totalNumPages++;
    free(emptyPage);

    return RC_OK;
}

RC ensureCapacity(int numberOfPages, SM_FileHandle *fHandle) {
    if (fHandle == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    while (fHandle->totalNumPages < numberOfPages) {
        if (appendEmptyBlock(fHandle) != RC_OK) {
            return RC_WRITE_FAILED;
        }
    }

    return RC_OK;
}
