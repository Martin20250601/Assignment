#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "record_mgr.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "dberror.h"

// 页面布局常量
#define SLOT_SIZE sizeof(int)
#define PAGE_HEADER_SIZE (sizeof(int) * 3)  // numSlots, freeSpace, nextFreePage
#define RECORDS_PER_PAGE_OFFSET (PAGE_SIZE - PAGE_HEADER_SIZE)

// 表信息页结构
typedef struct TableInfo {
    int numTuples;
    int recordSize;
    int firstFreePage;
    int numAttr;
    int keySize;
} TableInfo;

// 页面头部结构
typedef struct PageHeader {
    int numSlots;      // 页面中的槽位数
    int freeSpace;     // 空闲空间大小
    int nextFreePage;  // 下一个有空闲空间的页面
} PageHeader;

// 记录管理器数据结构
typedef struct RecordMgr {
    BM_BufferPool bufferPool;
    TableInfo *tableInfo;
    int isInitialized;
} RecordMgr;

// 扫描管理数据结构
typedef struct ScanMgmt {
    int currentPage;
    int currentSlot;
    Expr *condition;
    Record *record;
} ScanMgmt;

// 全局记录管理器
static RecordMgr *recordMgr = NULL;

// 内部函数声明
static RC attrOffset(Schema *schema, int attrNum, int *result);
static RC loadTableInfo(RM_TableData *rel);
static RC saveTableInfo(RM_TableData *rel);
static RC getPageHeader(BM_PageHandle *page, PageHeader *header);
static RC setPageHeader(BM_PageHandle *page, PageHeader *header);
static RC findFreeSlot(RM_TableData *rel, RID *rid);
static RC getRecordFromPage(BM_PageHandle *page, RID rid, Record *record, Schema *schema);
static RC setRecordInPage(BM_PageHandle *page, RID rid, Record *record, Schema *schema);
static RC deleteRecordFromPage(BM_PageHandle *page, RID rid, Schema *schema);
static bool evaluateCondition(Record *record, Schema *schema, Expr *condition);

// 记录管理器初始化和关闭
RC initRecordManager(void *mgmtData) {
    if (recordMgr != NULL) {
        return RC_OK;  // 已经初始化
    }
    
    recordMgr = (RecordMgr *)malloc(sizeof(RecordMgr));
    if (recordMgr == NULL) {
        return RC_WRITE_FAILED;
    }
    
    recordMgr->tableInfo = NULL;
    recordMgr->isInitialized = 1;
    
    return RC_OK;
}

RC shutdownRecordManager() {
    if (recordMgr == NULL) {
        return RC_OK;
    }
    
    if (recordMgr->tableInfo != NULL) {
        shutdownBufferPool(&recordMgr->bufferPool);
    }
    
    free(recordMgr);
    recordMgr = NULL;
    
    return RC_OK;
}

// 表管理函数
RC createTable(char *name, Schema *schema) {
    BM_BufferPool tempBufferPool;
    BM_PageHandle pageHandle;
    TableInfo tableInfo;
    char *pageData;
    int i;

    if (recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    // 创建页面文件
    if (createPageFile(name) != RC_OK) {
        return RC_WRITE_FAILED;
    }

    // 等待一下确保文件被写入磁盘
    // 使用临时缓冲池来创建表
    if (initBufferPool(&tempBufferPool, name, 10, RS_LRU, NULL) != RC_OK) {
        destroyPageFile(name);  // 清理创建的文件
        return RC_WRITE_FAILED;
    }
    
    // 获取第一个页面用于存储表信息
    if (pinPage(&tempBufferPool, &pageHandle, 0) != RC_OK) {
        shutdownBufferPool(&tempBufferPool);
        return RC_WRITE_FAILED;
    }
    
    // 初始化表信息
    tableInfo.numTuples = 0;
    tableInfo.recordSize = getRecordSize(schema);
    tableInfo.firstFreePage = 1;  // 第一个数据页
    tableInfo.numAttr = schema->numAttr;
    tableInfo.keySize = schema->keySize;
    
    // 将表信息写入页面
    pageData = pageHandle.data;
    memcpy(pageData, &tableInfo, sizeof(TableInfo));

    // 序列化schema信息到页面
    int offset = sizeof(TableInfo);

    // 写入数据类型数组
    memcpy(pageData + offset, schema->dataTypes, sizeof(DataType) * schema->numAttr);
    offset += sizeof(DataType) * schema->numAttr;

    // 写入类型长度数组
    memcpy(pageData + offset, schema->typeLength, sizeof(int) * schema->numAttr);
    offset += sizeof(int) * schema->numAttr;

    // 写入键属性数组
    if (schema->keySize > 0) {
        memcpy(pageData + offset, schema->keyAttrs, sizeof(int) * schema->keySize);
        offset += sizeof(int) * schema->keySize;
    }

    // 写入属性名
    for (i = 0; i < schema->numAttr; i++) {
        int nameLen = strlen(schema->attrNames[i]) + 1;
        memcpy(pageData + offset, &nameLen, sizeof(int));
        offset += sizeof(int);
        memcpy(pageData + offset, schema->attrNames[i], nameLen);
        offset += nameLen;
    }
    
    markDirty(&tempBufferPool, &pageHandle);
    unpinPage(&tempBufferPool, &pageHandle);

    // 关闭临时缓冲池，直接使用存储管理器创建页面1
    shutdownBufferPool(&tempBufferPool);

    // 使用存储管理器直接添加页面1
    SM_FileHandle fileHandle;
    if (openPageFile(name, &fileHandle) != RC_OK) {
        return RC_WRITE_FAILED;
    }

    if (appendEmptyBlock(&fileHandle) != RC_OK) {
        closePageFile(&fileHandle);
        return RC_WRITE_FAILED;
    }

    closePageFile(&fileHandle);
    
    return RC_OK;
}

RC openTable(RM_TableData *rel, char *name) {
    if (recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    // 如果已经有缓冲池打开，先关闭它
    if (recordMgr->tableInfo != NULL) {
        shutdownBufferPool(&recordMgr->bufferPool);
        recordMgr->tableInfo = NULL;
    }

    // 初始化缓冲池
    if (initBufferPool(&recordMgr->bufferPool, name, 10, RS_LRU, NULL) != RC_OK) {
        return RC_FILE_NOT_FOUND;
    }
    
    // 分配表数据结构
    rel->name = (char *)malloc(strlen(name) + 1);
    strcpy(rel->name, name);
    
    // 加载表信息
    if (loadTableInfo(rel) != RC_OK) {
        shutdownBufferPool(&recordMgr->bufferPool);
        free(rel->name);
        return RC_WRITE_FAILED;
    }
    
    rel->mgmtData = recordMgr;
    
    return RC_OK;
}

RC closeTable(RM_TableData *rel) {
    if (rel == NULL || recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    // 保存表信息
    saveTableInfo(rel);
    
    // 关闭缓冲池
    shutdownBufferPool(&recordMgr->bufferPool);
    
    // 释放schema内存
    if (rel->schema != NULL) {
        freeSchema(rel->schema);
    }
    
    free(rel->name);
    rel->mgmtData = NULL;
    
    return RC_OK;
}

RC deleteTable(char *name) {
    if (recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    return destroyPageFile(name);
}

int getNumTuples(RM_TableData *rel) {
    if (rel == NULL || recordMgr == NULL || recordMgr->tableInfo == NULL) {
        return 0;
    }
    
    return recordMgr->tableInfo->numTuples;
}

// Schema相关函数
int getRecordSize(Schema *schema) {
    int size = 0;
    int i;
    
    for (i = 0; i < schema->numAttr; i++) {
        switch (schema->dataTypes[i]) {
            case DT_INT:
                size += sizeof(int);
                break;
            case DT_FLOAT:
                size += sizeof(float);
                break;
            case DT_BOOL:
                size += sizeof(bool);
                break;
            case DT_STRING:
                size += schema->typeLength[i];
                break;
        }
    }
    
    return size;
}

Schema *createSchema(int numAttr, char **attrNames, DataType *dataTypes,
                     int *typeLength, int keySize, int *keys) {
    Schema *schema;
    int i;
    
    schema = (Schema *)malloc(sizeof(Schema));
    if (schema == NULL) {
        return NULL;
    }
    
    schema->numAttr = numAttr;
    schema->keySize = keySize;
    
    // 分配并复制属性名
    schema->attrNames = (char **)malloc(sizeof(char *) * numAttr);
    for (i = 0; i < numAttr; i++) {
        schema->attrNames[i] = (char *)malloc(strlen(attrNames[i]) + 1);
        strcpy(schema->attrNames[i], attrNames[i]);
    }
    
    // 分配并复制数据类型
    schema->dataTypes = (DataType *)malloc(sizeof(DataType) * numAttr);
    memcpy(schema->dataTypes, dataTypes, sizeof(DataType) * numAttr);
    
    // 分配并复制类型长度
    schema->typeLength = (int *)malloc(sizeof(int) * numAttr);
    memcpy(schema->typeLength, typeLength, sizeof(int) * numAttr);
    
    // 分配并复制键属性
    if (keySize > 0) {
        schema->keyAttrs = (int *)malloc(sizeof(int) * keySize);
        memcpy(schema->keyAttrs, keys, sizeof(int) * keySize);
    } else {
        schema->keyAttrs = NULL;
    }
    
    return schema;
}

RC freeSchema(Schema *schema) {
    int i;

    if (schema == NULL) {
        return RC_OK;
    }

    // 释放属性名
    if (schema->attrNames != NULL) {
        for (i = 0; i < schema->numAttr; i++) {
            free(schema->attrNames[i]);
        }
        free(schema->attrNames);
    }

    // 释放其他数组
    free(schema->dataTypes);
    free(schema->typeLength);
    free(schema->keyAttrs);
    free(schema);

    return RC_OK;
}

// Record相关函数
RC createRecord(Record **record, Schema *schema) {
    Record *newRecord;

    newRecord = (Record *)malloc(sizeof(Record));
    if (newRecord == NULL) {
        return RC_WRITE_FAILED;
    }

    newRecord->data = (char *)malloc(getRecordSize(schema));
    if (newRecord->data == NULL) {
        free(newRecord);
        return RC_WRITE_FAILED;
    }

    // 初始化RID
    newRecord->id.page = -1;
    newRecord->id.slot = -1;

    // 初始化数据为0
    memset(newRecord->data, 0, getRecordSize(schema));

    *record = newRecord;
    return RC_OK;
}

RC freeRecord(Record *record) {
    if (record == NULL) {
        return RC_OK;
    }

    free(record->data);
    free(record);

    return RC_OK;
}

RC getAttr(Record *record, Schema *schema, int attrNum, Value **value) {
    Value *attr;
    char *attrData;
    int offset;

    if (record == NULL || schema == NULL || attrNum < 0 || attrNum >= schema->numAttr) {
        return RC_RM_UNKOWN_DATATYPE;
    }

    // 计算属性偏移
    if (attrOffset(schema, attrNum, &offset) != RC_OK) {
        return RC_RM_UNKOWN_DATATYPE;
    }

    attrData = record->data + offset;
    attr = (Value *)malloc(sizeof(Value));
    if (attr == NULL) {
        return RC_WRITE_FAILED;
    }

    attr->dt = schema->dataTypes[attrNum];

    switch (schema->dataTypes[attrNum]) {
        case DT_INT:
            memcpy(&attr->v.intV, attrData, sizeof(int));
            break;
        case DT_FLOAT:
            memcpy(&attr->v.floatV, attrData, sizeof(float));
            break;
        case DT_BOOL:
            memcpy(&attr->v.boolV, attrData, sizeof(bool));
            break;
        case DT_STRING:
            attr->v.stringV = (char *)malloc(schema->typeLength[attrNum] + 1);
            if (attr->v.stringV == NULL) {
                free(attr);
                return RC_WRITE_FAILED;
            }
            memcpy(attr->v.stringV, attrData, schema->typeLength[attrNum]);
            attr->v.stringV[schema->typeLength[attrNum]] = '\0';
            break;
        default:
            free(attr);
            return RC_RM_UNKOWN_DATATYPE;
    }

    *value = attr;
    return RC_OK;
}

RC setAttr(Record *record, Schema *schema, int attrNum, Value *value) {
    char *attrData;
    int offset;

    if (record == NULL || schema == NULL || value == NULL ||
        attrNum < 0 || attrNum >= schema->numAttr) {
        return RC_RM_UNKOWN_DATATYPE;
    }

    if (value->dt != schema->dataTypes[attrNum]) {
        return RC_RM_UNKOWN_DATATYPE;
    }

    // 计算属性偏移
    if (attrOffset(schema, attrNum, &offset) != RC_OK) {
        return RC_RM_UNKOWN_DATATYPE;
    }

    attrData = record->data + offset;

    switch (schema->dataTypes[attrNum]) {
        case DT_INT:
            memcpy(attrData, &value->v.intV, sizeof(int));
            break;
        case DT_FLOAT:
            memcpy(attrData, &value->v.floatV, sizeof(float));
            break;
        case DT_BOOL:
            memcpy(attrData, &value->v.boolV, sizeof(bool));
            break;
        case DT_STRING:
            memcpy(attrData, value->v.stringV, schema->typeLength[attrNum]);
            break;
        default:
            return RC_RM_UNKOWN_DATATYPE;
    }

    return RC_OK;
}

// Record CRUD操作
RC insertRecord(RM_TableData *rel, Record *record) {
    BM_PageHandle pageHandle;
    RID rid;

    if (rel == NULL || record == NULL || recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    // 找到空闲槽位
    if (findFreeSlot(rel, &rid) != RC_OK) {
        return RC_WRITE_FAILED;
    }

    // 获取页面
    if (pinPage(&recordMgr->bufferPool, &pageHandle, rid.page) != RC_OK) {
        return RC_WRITE_FAILED;
    }

    // 将记录写入页面
    if (setRecordInPage(&pageHandle, rid, record, rel->schema) != RC_OK) {
        unpinPage(&recordMgr->bufferPool, &pageHandle);
        return RC_WRITE_FAILED;
    }

    // 更新记录的RID
    record->id = rid;

    // 更新表信息
    recordMgr->tableInfo->numTuples++;

    markDirty(&recordMgr->bufferPool, &pageHandle);
    unpinPage(&recordMgr->bufferPool, &pageHandle);

    return RC_OK;
}

RC deleteRecord(RM_TableData *rel, RID id) {
    BM_PageHandle pageHandle;

    if (rel == NULL || recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    // 获取页面
    if (pinPage(&recordMgr->bufferPool, &pageHandle, id.page) != RC_OK) {
        return RC_READ_NON_EXISTING_PAGE;
    }

    // 从页面删除记录
    if (deleteRecordFromPage(&pageHandle, id, rel->schema) != RC_OK) {
        unpinPage(&recordMgr->bufferPool, &pageHandle);
        return RC_WRITE_FAILED;
    }

    // 更新表信息
    recordMgr->tableInfo->numTuples--;

    markDirty(&recordMgr->bufferPool, &pageHandle);
    unpinPage(&recordMgr->bufferPool, &pageHandle);

    return RC_OK;
}

RC updateRecord(RM_TableData *rel, Record *record) {
    BM_PageHandle pageHandle;

    if (rel == NULL || record == NULL || recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    // 获取页面
    if (pinPage(&recordMgr->bufferPool, &pageHandle, record->id.page) != RC_OK) {
        return RC_READ_NON_EXISTING_PAGE;
    }

    // 更新页面中的记录
    if (setRecordInPage(&pageHandle, record->id, record, rel->schema) != RC_OK) {
        unpinPage(&recordMgr->bufferPool, &pageHandle);
        return RC_WRITE_FAILED;
    }

    markDirty(&recordMgr->bufferPool, &pageHandle);
    unpinPage(&recordMgr->bufferPool, &pageHandle);

    return RC_OK;
}

RC getRecord(RM_TableData *rel, RID id, Record *record) {
    BM_PageHandle pageHandle;

    if (rel == NULL || record == NULL || recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    // 获取页面
    if (pinPage(&recordMgr->bufferPool, &pageHandle, id.page) != RC_OK) {
        return RC_READ_NON_EXISTING_PAGE;
    }

    // 从页面读取记录
    if (getRecordFromPage(&pageHandle, id, record, rel->schema) != RC_OK) {
        unpinPage(&recordMgr->bufferPool, &pageHandle);
        return RC_READ_NON_EXISTING_PAGE;
    }

    record->id = id;
    unpinPage(&recordMgr->bufferPool, &pageHandle);

    return RC_OK;
}

// Scan功能
RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond) {
    ScanMgmt *scanMgmt;

    if (rel == NULL || scan == NULL || recordMgr == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    scanMgmt = (ScanMgmt *)malloc(sizeof(ScanMgmt));
    if (scanMgmt == NULL) {
        return RC_WRITE_FAILED;
    }

    // 初始化扫描管理数据
    scanMgmt->currentPage = 1;  // 从第一个数据页开始
    scanMgmt->currentSlot = 0;
    scanMgmt->condition = cond;

    // 创建记录用于扫描
    if (createRecord(&scanMgmt->record, rel->schema) != RC_OK) {
        free(scanMgmt);
        return RC_WRITE_FAILED;
    }

    scan->rel = rel;
    scan->mgmtData = scanMgmt;

    return RC_OK;
}

RC next(RM_ScanHandle *scan, Record *record) {
    ScanMgmt *scanMgmt;
    BM_PageHandle pageHandle;
    PageHeader header;
    RID rid;
    bool found = false;

    if (scan == NULL || record == NULL || scan->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    scanMgmt = (ScanMgmt *)scan->mgmtData;

    // 扫描所有页面和槽位
    while (!found) {
        // 尝试获取当前页面
        if (pinPage(&recordMgr->bufferPool, &pageHandle, scanMgmt->currentPage) != RC_OK) {
            return RC_RM_NO_MORE_TUPLES;
        }

        // 获取页面头部信息
        if (getPageHeader(&pageHandle, &header) != RC_OK) {
            unpinPage(&recordMgr->bufferPool, &pageHandle);
            return RC_RM_NO_MORE_TUPLES;
        }

        // 检查当前槽位是否有效
        if (scanMgmt->currentSlot < header.numSlots) {
            rid.page = scanMgmt->currentPage;
            rid.slot = scanMgmt->currentSlot;

            // 尝试读取记录
            if (getRecordFromPage(&pageHandle, rid, scanMgmt->record, scan->rel->schema) == RC_OK) {
                // 检查记录是否满足条件
                if (scanMgmt->condition == NULL ||
                    evaluateCondition(scanMgmt->record, scan->rel->schema, scanMgmt->condition)) {
                    // 复制记录数据
                    memcpy(record->data, scanMgmt->record->data, getRecordSize(scan->rel->schema));
                    record->id = rid;
                    found = true;
                }
            }

            scanMgmt->currentSlot++;
        } else {
            // 移动到下一页
            scanMgmt->currentPage++;
            scanMgmt->currentSlot = 0;

            // 检查是否还有更多页面
            if (scanMgmt->currentPage >= recordMgr->bufferPool.numPages + 10) {  // 简单的页面数量检查
                unpinPage(&recordMgr->bufferPool, &pageHandle);
                return RC_RM_NO_MORE_TUPLES;
            }
        }

        unpinPage(&recordMgr->bufferPool, &pageHandle);

        // 如果没找到记录且已经检查了很多页面，停止扫描
        if (!found && scanMgmt->currentPage > 100) {
            return RC_RM_NO_MORE_TUPLES;
        }
    }

    return RC_OK;
}

RC closeScan(RM_ScanHandle *scan) {
    ScanMgmt *scanMgmt;

    if (scan == NULL || scan->mgmtData == NULL) {
        return RC_OK;
    }

    scanMgmt = (ScanMgmt *)scan->mgmtData;

    // 释放扫描记录
    freeRecord(scanMgmt->record);

    // 释放扫描管理数据
    free(scanMgmt);
    scan->mgmtData = NULL;

    return RC_OK;
}

// 内部辅助函数实现
static RC attrOffset(Schema *schema, int attrNum, int *result) {
    int offset = 0;
    int i;

    if (attrNum < 0 || attrNum >= schema->numAttr) {
        return RC_RM_UNKOWN_DATATYPE;
    }

    for (i = 0; i < attrNum; i++) {
        switch (schema->dataTypes[i]) {
            case DT_INT:
                offset += sizeof(int);
                break;
            case DT_FLOAT:
                offset += sizeof(float);
                break;
            case DT_BOOL:
                offset += sizeof(bool);
                break;
            case DT_STRING:
                offset += schema->typeLength[i];
                break;
            default:
                return RC_RM_UNKOWN_DATATYPE;
        }
    }

    *result = offset;
    return RC_OK;
}

static RC loadTableInfo(RM_TableData *rel) {
    BM_PageHandle pageHandle;
    char *pageData;
    int offset, i, nameLen;

    // 获取表信息页
    if (pinPage(&recordMgr->bufferPool, &pageHandle, 0) != RC_OK) {
        return RC_WRITE_FAILED;
    }

    pageData = pageHandle.data;

    // 分配表信息结构
    recordMgr->tableInfo = (TableInfo *)malloc(sizeof(TableInfo));
    if (recordMgr->tableInfo == NULL) {
        unpinPage(&recordMgr->bufferPool, &pageHandle);
        return RC_WRITE_FAILED;
    }

    // 读取基本表信息
    memcpy(recordMgr->tableInfo, pageData, sizeof(TableInfo));

    // 分配schema结构
    rel->schema = (Schema *)malloc(sizeof(Schema));
    if (rel->schema == NULL) {
        free(recordMgr->tableInfo);
        unpinPage(&recordMgr->bufferPool, &pageHandle);
        return RC_WRITE_FAILED;
    }

    // 复制schema基本信息
    rel->schema->numAttr = recordMgr->tableInfo->numAttr;
    rel->schema->keySize = recordMgr->tableInfo->keySize;

    // 分配属性数组
    rel->schema->attrNames = (char **)malloc(sizeof(char *) * rel->schema->numAttr);
    rel->schema->dataTypes = (DataType *)malloc(sizeof(DataType) * rel->schema->numAttr);
    rel->schema->typeLength = (int *)malloc(sizeof(int) * rel->schema->numAttr);

    if (rel->schema->keySize > 0) {
        rel->schema->keyAttrs = (int *)malloc(sizeof(int) * rel->schema->keySize);
    } else {
        rel->schema->keyAttrs = NULL;
    }

    // 从页面读取schema数据
    offset = sizeof(TableInfo);

    // 读取数据类型数组
    memcpy(rel->schema->dataTypes, pageData + offset, sizeof(DataType) * rel->schema->numAttr);
    offset += sizeof(DataType) * rel->schema->numAttr;

    // 读取类型长度数组
    memcpy(rel->schema->typeLength, pageData + offset, sizeof(int) * rel->schema->numAttr);
    offset += sizeof(int) * rel->schema->numAttr;

    // 读取键属性数组
    if (rel->schema->keySize > 0) {
        memcpy(rel->schema->keyAttrs, pageData + offset, sizeof(int) * rel->schema->keySize);
        offset += sizeof(int) * rel->schema->keySize;
    }

    // 读取属性名（offset已经指向正确位置）
    for (i = 0; i < rel->schema->numAttr; i++) {
        memcpy(&nameLen, pageData + offset, sizeof(int));
        offset += sizeof(int);

        rel->schema->attrNames[i] = (char *)malloc(nameLen);
        memcpy(rel->schema->attrNames[i], pageData + offset, nameLen);
        offset += nameLen;
    }

    unpinPage(&recordMgr->bufferPool, &pageHandle);
    return RC_OK;
}

static RC saveTableInfo(RM_TableData *rel) {
    BM_PageHandle pageHandle;
    char *pageData;

    if (recordMgr->tableInfo == NULL) {
        return RC_OK;
    }

    // 获取表信息页
    if (pinPage(&recordMgr->bufferPool, &pageHandle, 0) != RC_OK) {
        return RC_WRITE_FAILED;
    }

    pageData = pageHandle.data;

    // 更新表信息
    memcpy(pageData, recordMgr->tableInfo, sizeof(TableInfo));

    markDirty(&recordMgr->bufferPool, &pageHandle);
    unpinPage(&recordMgr->bufferPool, &pageHandle);

    return RC_OK;
}

static RC getPageHeader(BM_PageHandle *page, PageHeader *header) {
    char *pageData = page->data;
    int offset = PAGE_SIZE - PAGE_HEADER_SIZE;

    memcpy(header, pageData + offset, sizeof(PageHeader));
    return RC_OK;
}

static RC setPageHeader(BM_PageHandle *page, PageHeader *header) {
    char *pageData = page->data;
    int offset = PAGE_SIZE - PAGE_HEADER_SIZE;

    memcpy(pageData + offset, header, sizeof(PageHeader));
    return RC_OK;
}

static RC findFreeSlot(RM_TableData *rel, RID *rid) {
    BM_PageHandle pageHandle;
    PageHeader header;
    int recordSize = getRecordSize(rel->schema);
    int slotsPerPage = (PAGE_SIZE - PAGE_HEADER_SIZE) / (recordSize + SLOT_SIZE);
    int currentPage = 1;  // 从页面1开始（页面0是表信息页）

    // 尝试现有页面
    while (currentPage < 10000) {  // 增加页面限制以支持大量记录
        if (pinPage(&recordMgr->bufferPool, &pageHandle, currentPage) == RC_OK) {
            getPageHeader(&pageHandle, &header);

            // 检查是否有空闲槽位
            if (header.numSlots < slotsPerPage) {
                rid->page = currentPage;
                rid->slot = header.numSlots;

                // 更新页面头部
                header.numSlots++;
                header.freeSpace -= (recordSize + SLOT_SIZE);
                setPageHeader(&pageHandle, &header);

                markDirty(&recordMgr->bufferPool, &pageHandle);
                unpinPage(&recordMgr->bufferPool, &pageHandle);

                return RC_OK;
            }
            unpinPage(&recordMgr->bufferPool, &pageHandle);
            currentPage++;
        } else {
            // 页面不存在，创建新页面
            break;
        }
    }

    // 创建新页面
    if (pinPage(&recordMgr->bufferPool, &pageHandle, currentPage) != RC_OK) {
        return RC_WRITE_FAILED;
    }

    // 初始化新页面头部
    header.numSlots = 0;
    header.freeSpace = PAGE_SIZE - PAGE_HEADER_SIZE;
    header.nextFreePage = -1;

    // 分配第一个槽位
    rid->page = currentPage;
    rid->slot = 0;

    // 更新页面头部（与现有页面逻辑一致）
    header.numSlots++;
    header.freeSpace -= (recordSize + SLOT_SIZE);
    setPageHeader(&pageHandle, &header);

    markDirty(&recordMgr->bufferPool, &pageHandle);
    unpinPage(&recordMgr->bufferPool, &pageHandle);

    return RC_OK;
}

static RC getRecordFromPage(BM_PageHandle *page, RID rid, Record *record, Schema *schema) {
    char *pageData = page->data;
    int recordSize = getRecordSize(schema);
    int offset = rid.slot * (recordSize + SLOT_SIZE);
    int slotValue;

    // 检查槽位是否有效
    memcpy(&slotValue, pageData + offset, SLOT_SIZE);
    if (slotValue == 0) {
        return RC_READ_NON_EXISTING_PAGE;  // 槽位为空
    }

    // 复制记录数据
    memcpy(record->data, pageData + offset + SLOT_SIZE, recordSize);

    return RC_OK;
}

static RC setRecordInPage(BM_PageHandle *page, RID rid, Record *record, Schema *schema) {
    char *pageData = page->data;
    int recordSize = getRecordSize(schema);
    int offset = rid.slot * (recordSize + SLOT_SIZE);
    int slotValue = 1;  // 标记槽位为已使用

    // 设置槽位标记
    memcpy(pageData + offset, &slotValue, SLOT_SIZE);

    // 复制记录数据
    memcpy(pageData + offset + SLOT_SIZE, record->data, recordSize);

    return RC_OK;
}

static RC deleteRecordFromPage(BM_PageHandle *page, RID rid, Schema *schema) {
    char *pageData = page->data;
    int recordSize = getRecordSize(schema);
    int offset = rid.slot * (recordSize + SLOT_SIZE);
    int slotValue = 0;  // 标记槽位为空

    // 清空槽位标记
    memcpy(pageData + offset, &slotValue, SLOT_SIZE);

    // 清空记录数据
    memset(pageData + offset + SLOT_SIZE, 0, recordSize);

    return RC_OK;
}

static bool evaluateCondition(Record *record, Schema *schema, Expr *condition) {
    Value *result;
    bool conditionResult;

    if (condition == NULL) {
        return true;  // 没有条件，返回所有记录
    }

    // 评估表达式
    if (evalExpr(record, schema, condition, &result) != RC_OK) {
        return false;
    }

    if (result->dt != DT_BOOL) {
        freeVal(result);
        return false;
    }

    conditionResult = result->v.boolV;
    freeVal(result);

    return conditionResult;
}
