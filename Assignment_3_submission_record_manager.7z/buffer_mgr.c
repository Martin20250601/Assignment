#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "dberror.h"

// 缓冲池管理数据结构
typedef struct BufferFrame {
    PageNumber pageNum;
    char *data;
    bool isDirty;
    int fixCount;
    int accessTime;  // 用于LRU策略
} BufferFrame;

typedef struct BufferPoolMgmt {
    BufferFrame *frames;
    SM_FileHandle fileHandle;
    int numReadIO;
    int numWriteIO;
    int accessCounter;  // 全局访问计数器
} BufferPoolMgmt;

// 内部函数声明
static int findFrame(BM_BufferPool *const bm, PageNumber pageNum);
static int findVictimFrame(BM_BufferPool *const bm);
static RC flushFrame(BM_BufferPool *const bm, int frameIndex);

RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName,
                  const int numPages, ReplacementStrategy strategy,
                  void *stratData) {
    BufferPoolMgmt *mgmt;
    int i;
    
    // 分配管理数据结构
    mgmt = (BufferPoolMgmt *)malloc(sizeof(BufferPoolMgmt));
    if (mgmt == NULL) {
        return RC_WRITE_FAILED;
    }
    
    // 分配缓冲帧数组
    mgmt->frames = (BufferFrame *)malloc(sizeof(BufferFrame) * numPages);
    if (mgmt->frames == NULL) {
        free(mgmt);
        return RC_WRITE_FAILED;
    }
    
    // 初始化缓冲帧
    for (i = 0; i < numPages; i++) {
        mgmt->frames[i].pageNum = NO_PAGE;
        mgmt->frames[i].data = (char *)malloc(PAGE_SIZE);
        mgmt->frames[i].isDirty = false;
        mgmt->frames[i].fixCount = 0;
        mgmt->frames[i].accessTime = 0;
        
        if (mgmt->frames[i].data == NULL) {
            // 清理已分配的内存
            int j;
            for (j = 0; j < i; j++) {
                free(mgmt->frames[j].data);
            }
            free(mgmt->frames);
            free(mgmt);
            return RC_WRITE_FAILED;
        }
    }
    
    // 打开页面文件
    if (openPageFile((char *)pageFileName, &mgmt->fileHandle) != RC_OK) {
        // 清理内存
        for (i = 0; i < numPages; i++) {
            free(mgmt->frames[i].data);
        }
        free(mgmt->frames);
        free(mgmt);
        return RC_FILE_NOT_FOUND;
    }
    
    mgmt->numReadIO = 0;
    mgmt->numWriteIO = 0;
    mgmt->accessCounter = 0;
    
    // 设置缓冲池参数
    bm->pageFile = (char *)malloc(strlen(pageFileName) + 1);
    strcpy(bm->pageFile, pageFileName);
    bm->numPages = numPages;
    bm->strategy = strategy;
    bm->mgmtData = mgmt;
    
    return RC_OK;
}

RC shutdownBufferPool(BM_BufferPool *const bm) {
    BufferPoolMgmt *mgmt;
    int i;
    
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    mgmt = (BufferPoolMgmt *)bm->mgmtData;
    
    // 检查是否有页面仍被固定
    for (i = 0; i < bm->numPages; i++) {
        if (mgmt->frames[i].fixCount > 0) {
            return RC_WRITE_FAILED;  // 有页面仍被固定
        }
    }
    
    // 刷新所有脏页
    if (forceFlushPool(bm) != RC_OK) {
        return RC_WRITE_FAILED;
    }
    
    // 关闭文件
    closePageFile(&mgmt->fileHandle);
    
    // 释放内存
    for (i = 0; i < bm->numPages; i++) {
        free(mgmt->frames[i].data);
    }
    free(mgmt->frames);
    free(mgmt);
    free(bm->pageFile);
    
    bm->mgmtData = NULL;
    
    return RC_OK;
}

RC forceFlushPool(BM_BufferPool *const bm) {
    BufferPoolMgmt *mgmt;
    int i;
    
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    mgmt = (BufferPoolMgmt *)bm->mgmtData;
    
    for (i = 0; i < bm->numPages; i++) {
        if (mgmt->frames[i].isDirty && mgmt->frames[i].fixCount == 0) {
            if (flushFrame(bm, i) != RC_OK) {
                return RC_WRITE_FAILED;
            }
        }
    }
    
    return RC_OK;
}

RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page) {
    BufferPoolMgmt *mgmt;
    int frameIndex;
    
    if (bm == NULL || bm->mgmtData == NULL || page == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    mgmt = (BufferPoolMgmt *)bm->mgmtData;
    frameIndex = findFrame(bm, page->pageNum);
    
    if (frameIndex == -1) {
        return RC_READ_NON_EXISTING_PAGE;
    }
    
    mgmt->frames[frameIndex].isDirty = true;
    return RC_OK;
}

RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    BufferPoolMgmt *mgmt;
    int frameIndex;
    
    if (bm == NULL || bm->mgmtData == NULL || page == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    mgmt = (BufferPoolMgmt *)bm->mgmtData;
    frameIndex = findFrame(bm, page->pageNum);
    
    if (frameIndex == -1) {
        return RC_READ_NON_EXISTING_PAGE;
    }
    
    if (mgmt->frames[frameIndex].fixCount > 0) {
        mgmt->frames[frameIndex].fixCount--;
    }
    
    return RC_OK;
}

RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    BufferPoolMgmt *mgmt;
    int frameIndex;
    
    if (bm == NULL || bm->mgmtData == NULL || page == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    mgmt = (BufferPoolMgmt *)bm->mgmtData;
    frameIndex = findFrame(bm, page->pageNum);
    
    if (frameIndex == -1) {
        return RC_READ_NON_EXISTING_PAGE;
    }
    
    return flushFrame(bm, frameIndex);
}

RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page,
           const PageNumber pageNum) {
    BufferPoolMgmt *mgmt;
    int frameIndex;
    
    if (bm == NULL || bm->mgmtData == NULL || page == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    mgmt = (BufferPoolMgmt *)bm->mgmtData;
    
    // 检查页面是否已在缓冲池中
    frameIndex = findFrame(bm, pageNum);
    
    if (frameIndex != -1) {
        // 页面已在缓冲池中
        mgmt->frames[frameIndex].fixCount++;
        mgmt->frames[frameIndex].accessTime = ++mgmt->accessCounter;
        page->pageNum = pageNum;
        page->data = mgmt->frames[frameIndex].data;
        return RC_OK;
    }
    
    // 页面不在缓冲池中，需要加载
    frameIndex = findVictimFrame(bm);
    
    if (frameIndex == -1) {
        return RC_WRITE_FAILED;  // 没有可用的帧
    }
    
    // 如果受害帧是脏的，先写回磁盘
    if (mgmt->frames[frameIndex].isDirty) {
        if (flushFrame(bm, frameIndex) != RC_OK) {
            return RC_WRITE_FAILED;
        }
    }
    
    // 从磁盘读取页面，如果页面不存在则创建它
    if (readBlock(pageNum, &mgmt->fileHandle, mgmt->frames[frameIndex].data) != RC_OK) {
        // 页面不存在，尝试创建它
        if (pageNum >= mgmt->fileHandle.totalNumPages) {
            // 确保文件有足够的页面
            if (ensureCapacity(pageNum + 1, &mgmt->fileHandle) != RC_OK) {
                return RC_WRITE_FAILED;
            }
            // 初始化页面为空
            memset(mgmt->frames[frameIndex].data, 0, PAGE_SIZE);
            // 新创建的页面，不增加读IO计数
        } else {
            return RC_READ_NON_EXISTING_PAGE;
        }
    } else {
        // 成功从磁盘读取页面
        mgmt->numReadIO++;
    }
    
    // 更新帧信息
    mgmt->frames[frameIndex].pageNum = pageNum;
    mgmt->frames[frameIndex].isDirty = false;
    mgmt->frames[frameIndex].fixCount = 1;
    mgmt->frames[frameIndex].accessTime = ++mgmt->accessCounter;
    
    page->pageNum = pageNum;
    page->data = mgmt->frames[frameIndex].data;
    
    return RC_OK;
}

// 内部函数实现
static int findFrame(BM_BufferPool *const bm, PageNumber pageNum) {
    BufferPoolMgmt *mgmt = (BufferPoolMgmt *)bm->mgmtData;
    int i;
    
    for (i = 0; i < bm->numPages; i++) {
        if (mgmt->frames[i].pageNum == pageNum) {
            return i;
        }
    }
    
    return -1;
}

static int findVictimFrame(BM_BufferPool *const bm) {
    BufferPoolMgmt *mgmt = (BufferPoolMgmt *)bm->mgmtData;
    int i, victim = -1;
    int minAccessTime = mgmt->accessCounter + 1;
    
    // 首先寻找空闲帧
    for (i = 0; i < bm->numPages; i++) {
        if (mgmt->frames[i].pageNum == NO_PAGE) {
            return i;
        }
    }
    
    // 使用LRU策略寻找受害帧
    for (i = 0; i < bm->numPages; i++) {
        if (mgmt->frames[i].fixCount == 0 && 
            mgmt->frames[i].accessTime < minAccessTime) {
            minAccessTime = mgmt->frames[i].accessTime;
            victim = i;
        }
    }
    
    return victim;
}

static RC flushFrame(BM_BufferPool *const bm, int frameIndex) {
    BufferPoolMgmt *mgmt = (BufferPoolMgmt *)bm->mgmtData;
    
    if (writeBlock(mgmt->frames[frameIndex].pageNum, &mgmt->fileHandle,
                   mgmt->frames[frameIndex].data) != RC_OK) {
        return RC_WRITE_FAILED;
    }
    
    mgmt->numWriteIO++;
    mgmt->frames[frameIndex].isDirty = false;
    
    return RC_OK;
}

// 统计接口实现
PageNumber *getFrameContents(BM_BufferPool *const bm) {
    BufferPoolMgmt *mgmt = (BufferPoolMgmt *)bm->mgmtData;
    PageNumber *result = (PageNumber *)malloc(sizeof(PageNumber) * bm->numPages);
    int i;
    
    for (i = 0; i < bm->numPages; i++) {
        result[i] = mgmt->frames[i].pageNum;
    }
    
    return result;
}

bool *getDirtyFlags(BM_BufferPool *const bm) {
    BufferPoolMgmt *mgmt = (BufferPoolMgmt *)bm->mgmtData;
    bool *result = (bool *)malloc(sizeof(bool) * bm->numPages);
    int i;
    
    for (i = 0; i < bm->numPages; i++) {
        result[i] = mgmt->frames[i].isDirty;
    }
    
    return result;
}

int *getFixCounts(BM_BufferPool *const bm) {
    BufferPoolMgmt *mgmt = (BufferPoolMgmt *)bm->mgmtData;
    int *result = (int *)malloc(sizeof(int) * bm->numPages);
    int i;
    
    for (i = 0; i < bm->numPages; i++) {
        result[i] = mgmt->frames[i].fixCount;
    }
    
    return result;
}

int getNumReadIO(BM_BufferPool *const bm) {
    BufferPoolMgmt *mgmt = (BufferPoolMgmt *)bm->mgmtData;
    return mgmt->numReadIO;
}

int getNumWriteIO(BM_BufferPool *const bm) {
    BufferPoolMgmt *mgmt = (BufferPoolMgmt *)bm->mgmtData;
    return mgmt->numWriteIO;
}
