#include <stdio.h>
#include <stdlib.h>
#include "btree_mgr.h"
#include "dberror.h"
#include "tables.h"
#include "test_helper.h"

char *testName = "simple insert test";

int main() {
    printf("Starting B+Tree test...\n");
    fflush(stdout);
    
    // Initialize
    RC result = initIndexManager(NULL);
    printf("initIndexManager result: %d\n", result);
    if (result != RC_OK) {
        printf("Failed to initialize\n");
        return 1;
    }
    
    // Create B-tree
    result = createBtree("testidx", DT_INT, 2);
    printf("createBtree result: %d\n", result);
    if (result != RC_OK) {
        printf("Failed to create B-tree\n");
        return 1;
    }
    
    // Open B-tree
    BTreeHandle *tree = NULL;
    result = openBtree(&tree, "testidx");
    printf("openBtree result: %d\n", result);
    if (result != RC_OK) {
        printf("Failed to open B-tree\n");
        return 1;
    }
    
    // Test simple insertion
    Value *key = (Value *) malloc(sizeof(Value));
    key->dt = DT_INT;
    key->v.intV = 1;
    
    RID rid = {1, 1};
    
    result = insertKey(tree, key, rid);
    printf("insertKey result: %d\n", result);
    if (result != RC_OK) {
        printf("Failed to insert key\n");
        return 1;
    }
    
    // Test find
    RID foundRid;
    result = findKey(tree, key, &foundRid);
    printf("findKey result: %d\n", result);
    if (result == RC_OK) {
        printf("Found RID: page=%d, slot=%d\n", foundRid.page, foundRid.slot);
    }
    
    // Get stats
    int numNodes, numEntries;
    getNumNodes(tree, &numNodes);
    getNumEntries(tree, &numEntries);
    printf("Nodes: %d, Entries: %d\n", numNodes, numEntries);
    
    // Cleanup
    closeBtree(tree);
    deleteBtree("testidx");
    shutdownIndexManager();
    
    printf("Test completed!\n");
    return 0;
}
