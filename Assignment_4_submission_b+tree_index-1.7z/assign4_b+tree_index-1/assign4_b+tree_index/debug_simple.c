#include <stdio.h>
#include <stdlib.h>
#include "btree_mgr.h"
#include "dberror.h"
#include "tables.h"

int main() {
    printf("Starting simple debug test...\n");
    fflush(stdout);
    
    // Test initialization
    RC rc = initIndexManager(NULL);
    printf("initIndexManager returned: %d\n", rc);
    fflush(stdout);
    
    if (rc != RC_OK) {
        printf("Failed to initialize index manager\n");
        return 1;
    }
    
    // Test create B-tree
    rc = createBtree("testidx", DT_INT, 2);
    printf("createBtree returned: %d\n", rc);
    fflush(stdout);
    
    if (rc != RC_OK) {
        printf("Failed to create B-tree\n");
        return 1;
    }
    
    // Test open B-tree
    BTreeHandle *tree = NULL;
    rc = openBtree(&tree, "testidx");
    printf("openBtree returned: %d\n", rc);
    fflush(stdout);
    
    if (rc != RC_OK) {
        printf("Failed to open B-tree\n");
        return 1;
    }
    
    printf("B-tree opened successfully\n");
    
    // Test insert a key
    Value *key = (Value *) malloc(sizeof(Value));
    key->dt = DT_INT;
    key->v.intV = 1;
    
    RID rid = {1, 1};
    
    rc = insertKey(tree, key, rid);
    printf("insertKey returned: %d\n", rc);
    fflush(stdout);
    
    if (rc != RC_OK) {
        printf("Failed to insert key\n");
        return 1;
    }
    
    printf("Key inserted successfully\n");
    
    // Test find key
    RID foundRid;
    rc = findKey(tree, key, &foundRid);
    printf("findKey returned: %d\n", rc);
    fflush(stdout);
    
    if (rc == RC_OK) {
        printf("Found key: page=%d, slot=%d\n", foundRid.page, foundRid.slot);
    } else {
        printf("Key not found\n");
    }
    
    // Cleanup
    free(key);
    closeBtree(tree);
    deleteBtree("testidx");
    shutdownIndexManager();
    
    printf("Test completed successfully!\n");
    return 0;
}
