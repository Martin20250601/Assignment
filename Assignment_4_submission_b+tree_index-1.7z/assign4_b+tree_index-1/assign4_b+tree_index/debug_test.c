#include <stdio.h>
#include <stdlib.h>
#include "btree_mgr.h"
#include "dberror.h"

int main() {
    printf("Starting debug test...\n");
    fflush(stdout);
    
    // Test basic initialization
    RC result = initIndexManager(NULL);
    printf("initIndexManager result: %d\n", result);
    fflush(stdout);
    
    if (result != RC_OK) {
        printf("Failed to initialize index manager\n");
        return 1;
    }
    
    // Test creating B-tree
    result = createBtree("debug_test", DT_INT, 2);
    printf("createBtree result: %d\n", result);
    fflush(stdout);
    
    if (result != RC_OK) {
        printf("Failed to create B-tree\n");
        return 1;
    }
    
    printf("Debug test completed successfully!\n");
    fflush(stdout);
    
    return 0;
}
