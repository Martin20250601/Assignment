#include <stdio.h>

int main() {
    printf("Hello World!\n");
    fflush(stdout);
    return 0;
}
