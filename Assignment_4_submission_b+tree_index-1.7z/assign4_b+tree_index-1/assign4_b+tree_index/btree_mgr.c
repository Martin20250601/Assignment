#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "btree_mgr.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "dberror.h"
#include "tables.h"

// B+Tree node types
typedef enum NodeType {
    NT_LEAF,
    NT_INTERNAL
} NodeType;

// B+Tree node structure
typedef struct BTreeNode {
    NodeType nodeType;
    int numKeys;
    int *keys;
    void **pointers;
    struct BTreeNode *parent;
    struct BTreeNode *next;  // For leaf nodes only
} BTreeNode;

// B+Tree management data
typedef struct BTreeMgmtData {
    BM_BufferPool *bufferPool;
    BM_PageHandle *pageHandle;
    int order;  // n parameter
    int numNodes;
    int numEntries;
    BTreeNode *root;
    DataType keyType;
    char *idxId;
} BTreeMgmtData;

// Scan management data
typedef struct BT_ScanMgmtData {
    BTreeNode *currentNode;
    int currentIndex;
    int totalScanned;
} BT_ScanMgmtData;

// Global variables
static bool isInitialized = false;

// Helper function declarations
static BTreeNode *createNode(int order, NodeType nodeType);
static void destroyNode(BTreeNode *node);
static BTreeNode *findLeaf(BTreeNode *root, int key);
static RC insertIntoLeaf(BTreeMgmtData *mgmt, BTreeNode *leaf, int key, RID rid);
static RC insertIntoParent(BTreeMgmtData *mgmt, BTreeNode *left, int key, BTreeNode *right);


static RC deleteFromLeaf(BTreeMgmtData *mgmt, BTreeNode *leaf, int key);
static int compareKeys(Value *key1, Value *key2);
static char *serializeTree(BTreeNode *root, int *nodeCounter);
static void serializeNode(BTreeNode *node, char *result, int nodeId, int *nodeCounter);

// Index Manager Functions
RC initIndexManager(void *mgmtData) {
    if (isInitialized) {
        return RC_OK;
    }

    // Initialize storage manager
    initStorageManager();
    isInitialized = true;

    return RC_OK;
}

RC shutdownIndexManager() {
    if (!isInitialized) {
        return RC_OK;
    }

    isInitialized = false;
    return RC_OK;
}

// B+Tree Functions
RC createBtree(char *idxId, DataType keyType, int n) {
    if (!isInitialized) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    if (keyType != DT_INT) {
        return RC_IM_N_TO_LAGE;  // Only support DT_INT for now
    }

    if (n < 2) {
        return RC_IM_N_TO_LAGE;
    }

    // Create page file for the index
    RC result = createPageFile(idxId);
    if (result != RC_OK) {
        return result;
    }

    // Initialize the first page with metadata
    SM_FileHandle fileHandle;
    result = openPageFile(idxId, &fileHandle);
    if (result != RC_OK) {
        return result;
    }

    // Write metadata to first page
    SM_PageHandle pageData = (SM_PageHandle) calloc(PAGE_SIZE, sizeof(char));
    sprintf(pageData, "%d,%d,%d,%d", keyType, n, 0, 0); // keyType, order, numNodes, numEntries

    result = writeBlock(0, &fileHandle, pageData);
    free(pageData);
    closePageFile(&fileHandle);

    return result;
}

RC openBtree(BTreeHandle **tree, char *idxId) {
    if (!isInitialized) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    // Allocate tree handle
    *tree = (BTreeHandle *) malloc(sizeof(BTreeHandle));
    (*tree)->idxId = (char *) malloc(strlen(idxId) + 1);
    strcpy((*tree)->idxId, idxId);

    // Allocate management data
    BTreeMgmtData *mgmt = (BTreeMgmtData *) malloc(sizeof(BTreeMgmtData));
    mgmt->bufferPool = (BM_BufferPool *) malloc(sizeof(BM_BufferPool));
    mgmt->pageHandle = (BM_PageHandle *) malloc(sizeof(BM_PageHandle));
    mgmt->idxId = (char *) malloc(strlen(idxId) + 1);
    strcpy(mgmt->idxId, idxId);

    // Initialize buffer pool
    RC result = initBufferPool(mgmt->bufferPool, idxId, 100, RS_FIFO, NULL);
    if (result != RC_OK) {
        free(mgmt->idxId);
        free(mgmt->pageHandle);
        free(mgmt->bufferPool);
        free(mgmt);
        free((*tree)->idxId);
        free(*tree);
        return result;
    }

    // Read metadata from first page
    result = pinPage(mgmt->bufferPool, mgmt->pageHandle, 0);
    if (result != RC_OK) {
        shutdownBufferPool(mgmt->bufferPool);
        free(mgmt->idxId);
        free(mgmt->pageHandle);
        free(mgmt->bufferPool);
        free(mgmt);
        free((*tree)->idxId);
        free(*tree);
        return result;
    }

    // Parse metadata
    int keyType, order, numNodes, numEntries;
    sscanf(mgmt->pageHandle->data, "%d,%d,%d,%d", &keyType, &order, &numNodes, &numEntries);

    mgmt->keyType = (DataType) keyType;
    mgmt->order = order;
    mgmt->numNodes = numNodes;
    mgmt->numEntries = numEntries;
    mgmt->root = NULL;

    unpinPage(mgmt->bufferPool, mgmt->pageHandle);

    (*tree)->keyType = mgmt->keyType;
    (*tree)->mgmtData = mgmt;

    return RC_OK;
}

RC closeBtree(BTreeHandle *tree) {
    if (tree == NULL || tree->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;

    // Update metadata in first page
    RC result = pinPage(mgmt->bufferPool, mgmt->pageHandle, 0);
    if (result == RC_OK) {
        sprintf(mgmt->pageHandle->data, "%d,%d,%d,%d",
                mgmt->keyType, mgmt->order, mgmt->numNodes, mgmt->numEntries);
        markDirty(mgmt->bufferPool, mgmt->pageHandle);
        unpinPage(mgmt->bufferPool, mgmt->pageHandle);
    }

    // Shutdown buffer pool
    shutdownBufferPool(mgmt->bufferPool);

    // Free memory
    free(mgmt->idxId);
    free(mgmt->pageHandle);
    free(mgmt->bufferPool);
    free(mgmt);
    free(tree->idxId);
    free(tree);

    return RC_OK;
}

RC deleteBtree(char *idxId) {
    if (!isInitialized) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    return destroyPageFile(idxId);
}

// Access information functions
RC getNumNodes(BTreeHandle *tree, int *result) {
    if (tree == NULL || tree->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;
    *result = mgmt->numNodes;



    return RC_OK;
}

RC getNumEntries(BTreeHandle *tree, int *result) {
    if (tree == NULL || tree->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;
    *result = mgmt->numEntries;

    return RC_OK;
}

RC getKeyType(BTreeHandle *tree, DataType *result) {
    if (tree == NULL || tree->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;
    *result = mgmt->keyType;

    return RC_OK;
}

// Key access functions
RC findKey(BTreeHandle *tree, Value *key, RID *result) {
    if (tree == NULL || tree->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;

    if (mgmt->root == NULL) {
        return RC_IM_KEY_NOT_FOUND;
    }

    if (key->dt != mgmt->keyType) {
        return RC_RM_COMPARE_VALUE_OF_DIFFERENT_DATATYPE;
    }

    BTreeNode *leaf = findLeaf(mgmt->root, key->v.intV);
    if (leaf == NULL) {
        return RC_IM_KEY_NOT_FOUND;
    }

    // Search for key in leaf node
    for (int i = 0; i < leaf->numKeys; i++) {
        if (leaf->keys[i] == key->v.intV) {
            *result = *((RID *) leaf->pointers[i]);
            return RC_OK;
        }
    }

    return RC_IM_KEY_NOT_FOUND;
}

RC insertKey(BTreeHandle *tree, Value *key, RID rid) {
    if (tree == NULL || tree->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;

    if (key->dt != mgmt->keyType) {
        return RC_RM_COMPARE_VALUE_OF_DIFFERENT_DATATYPE;
    }

    // Check if key already exists
    RID existingRid;
    if (findKey(tree, key, &existingRid) == RC_OK) {
        return RC_IM_KEY_ALREADY_EXISTS;
    }

    // If tree is empty, create root
    if (mgmt->root == NULL) {
        mgmt->root = createNode(mgmt->order, NT_LEAF);
        mgmt->numNodes = 1;
    }

    BTreeNode *leaf = findLeaf(mgmt->root, key->v.intV);
    RC result = insertIntoLeaf(mgmt, leaf, key->v.intV, rid);

    if (result == RC_OK) {
        mgmt->numEntries++;
    }

    return result;
}

RC deleteKey(BTreeHandle *tree, Value *key) {
    if (tree == NULL || tree->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;

    if (mgmt->root == NULL) {
        return RC_IM_KEY_NOT_FOUND;
    }

    if (key->dt != mgmt->keyType) {
        return RC_RM_COMPARE_VALUE_OF_DIFFERENT_DATATYPE;
    }

    BTreeNode *leaf = findLeaf(mgmt->root, key->v.intV);
    if (leaf == NULL) {
        return RC_IM_KEY_NOT_FOUND;
    }

    RC result = deleteFromLeaf(mgmt, leaf, key->v.intV);

    if (result == RC_OK) {
        mgmt->numEntries--;
    }

    return result;
}

// Scan functions
RC openTreeScan(BTreeHandle *tree, BT_ScanHandle **handle) {
    if (tree == NULL || tree->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;

    *handle = (BT_ScanHandle *) malloc(sizeof(BT_ScanHandle));
    (*handle)->tree = tree;

    BT_ScanMgmtData *scanMgmt = (BT_ScanMgmtData *) malloc(sizeof(BT_ScanMgmtData));
    scanMgmt->currentIndex = 0;
    scanMgmt->totalScanned = 0;

    // Find leftmost leaf node
    if (mgmt->root == NULL) {
        scanMgmt->currentNode = NULL;
    } else {
        BTreeNode *current = mgmt->root;
        while (current->nodeType != NT_LEAF) {
            current = (BTreeNode *) current->pointers[0];
        }
        scanMgmt->currentNode = current;
    }

    (*handle)->mgmtData = scanMgmt;

    return RC_OK;
}

RC nextEntry(BT_ScanHandle *handle, RID *result) {
    if (handle == NULL || handle->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BT_ScanMgmtData *scanMgmt = (BT_ScanMgmtData *) handle->mgmtData;

    if (scanMgmt->currentNode == NULL) {
        return RC_IM_NO_MORE_ENTRIES;
    }

    // Check if we have more entries in current node
    if (scanMgmt->currentIndex < scanMgmt->currentNode->numKeys) {
        *result = *((RID *) scanMgmt->currentNode->pointers[scanMgmt->currentIndex]);
        scanMgmt->currentIndex++;
        scanMgmt->totalScanned++;
        return RC_OK;
    }

    // Move to next leaf node
    scanMgmt->currentNode = scanMgmt->currentNode->next;
    scanMgmt->currentIndex = 0;

    if (scanMgmt->currentNode == NULL) {
        return RC_IM_NO_MORE_ENTRIES;
    }

    if (scanMgmt->currentNode->numKeys > 0) {
        *result = *((RID *) scanMgmt->currentNode->pointers[0]);
        scanMgmt->currentIndex = 1;
        scanMgmt->totalScanned++;
        return RC_OK;
    }

    return RC_IM_NO_MORE_ENTRIES;
}

RC closeTreeScan(BT_ScanHandle *handle) {
    if (handle == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    if (handle->mgmtData != NULL) {
        free(handle->mgmtData);
    }
    free(handle);

    return RC_OK;
}

// Helper function implementations
static BTreeNode *createNode(int order, NodeType nodeType) {
    BTreeNode *node = (BTreeNode *) malloc(sizeof(BTreeNode));
    node->nodeType = nodeType;
    node->numKeys = 0;
    node->keys = (int *) malloc(order * sizeof(int));
    node->pointers = (void **) malloc((order + 1) * sizeof(void *));
    node->parent = NULL;
    node->next = NULL;

    // Initialize pointers to NULL
    for (int i = 0; i <= order; i++) {
        node->pointers[i] = NULL;
    }

    return node;
}

static void destroyNode(BTreeNode *node) {
    if (node == NULL) return;

    // Free RID pointers for leaf nodes
    if (node->nodeType == NT_LEAF) {
        for (int i = 0; i < node->numKeys; i++) {
            if (node->pointers[i] != NULL) {
                free(node->pointers[i]);
            }
        }
    }

    free(node->keys);
    free(node->pointers);
    free(node);
}

static BTreeNode *findLeaf(BTreeNode *root, int key) {
    if (root == NULL) return NULL;

    BTreeNode *current = root;

    while (current->nodeType != NT_LEAF) {
        int i = 0;
        while (i < current->numKeys && key >= current->keys[i]) {
            i++;
        }
        current = (BTreeNode *) current->pointers[i];
    }

    return current;
}

static int compareKeys(Value *key1, Value *key2) {
    if (key1->dt != key2->dt) {
        return -2; // Error: different types
    }

    switch (key1->dt) {
        case DT_INT:
            if (key1->v.intV < key2->v.intV) return -1;
            if (key1->v.intV > key2->v.intV) return 1;
            return 0;
        case DT_FLOAT:
            if (key1->v.floatV < key2->v.floatV) return -1;
            if (key1->v.floatV > key2->v.floatV) return 1;
            return 0;
        case DT_STRING:
            return strcmp(key1->v.stringV, key2->v.stringV);
        case DT_BOOL:
            if (key1->v.boolV < key2->v.boolV) return -1;
            if (key1->v.boolV > key2->v.boolV) return 1;
            return 0;
        default:
            return -2; // Error: unknown type
    }
}

static RC insertIntoLeaf(BTreeMgmtData *mgmt, BTreeNode *leaf, int key, RID rid) {
    // Find insertion position
    int insertPos = 0;
    while (insertPos < leaf->numKeys && leaf->keys[insertPos] < key) {
        insertPos++;
    }

    // Check if key already exists
    if (insertPos < leaf->numKeys && leaf->keys[insertPos] == key) {
        return RC_IM_KEY_ALREADY_EXISTS;
    }

    // If leaf has space, insert directly
    // For B+tree with order n, each node can hold n keys
    if (leaf->numKeys < mgmt->order) {
        // Shift keys and pointers to make room
        for (int i = leaf->numKeys; i > insertPos; i--) {
            leaf->keys[i] = leaf->keys[i - 1];
            leaf->pointers[i] = leaf->pointers[i - 1];
        }

        // Insert new key and RID
        leaf->keys[insertPos] = key;
        RID *ridPtr = (RID *) malloc(sizeof(RID));
        *ridPtr = rid;
        leaf->pointers[insertPos] = ridPtr;
        leaf->numKeys++;

        return RC_OK;
    }

    // Leaf is full, need to split
    // Create temporary array to hold all keys including the new one
    int tempKeys[mgmt->order + 1];
    RID *tempRids[mgmt->order + 1];

    // Copy existing keys and insert new key in correct position
    int j = 0;
    for (int i = 0; i <= leaf->numKeys; i++) {
        if (i == insertPos) {
            tempKeys[i] = key;
            tempRids[i] = (RID *) malloc(sizeof(RID));
            *tempRids[i] = rid;
        } else {
            tempKeys[i] = leaf->keys[j];
            tempRids[i] = (RID *) leaf->pointers[j];
            j++;
        }
    }

    // Create new leaf
    BTreeNode *newLeaf = createNode(mgmt->order, NT_LEAF);

    // Split according to assignment rules
    // For B+tree with order n, when splitting a leaf:
    // We want to split (n+1) keys into two nodes
    // Left node gets ceil((n+1)/2) keys
    // Right node gets floor((n+1)/2) keys
    int totalKeys = mgmt->order + 1;
    int splitPoint = (totalKeys + 1) / 2;

    // Distribute keys
    leaf->numKeys = splitPoint;
    for (int i = 0; i < splitPoint; i++) {
        leaf->keys[i] = tempKeys[i];
        leaf->pointers[i] = tempRids[i];
    }

    newLeaf->numKeys = (mgmt->order + 1) - splitPoint;
    for (int i = 0; i < newLeaf->numKeys; i++) {
        newLeaf->keys[i] = tempKeys[splitPoint + i];
        newLeaf->pointers[i] = tempRids[splitPoint + i];
    }

    // Update linked list pointers
    newLeaf->next = leaf->next;
    leaf->next = newLeaf;
    newLeaf->parent = leaf->parent;

    mgmt->numNodes++;

    // Insert into parent
    return insertIntoParent(mgmt, leaf, newLeaf->keys[0], newLeaf);
}



static RC insertIntoParent(BTreeMgmtData *mgmt, BTreeNode *left, int key, BTreeNode *right) {
    // If left is root, create new root
    if (left->parent == NULL) {
        BTreeNode *newRoot = createNode(mgmt->order, NT_INTERNAL);
        newRoot->keys[0] = key;
        newRoot->pointers[0] = left;
        newRoot->pointers[1] = right;
        newRoot->numKeys = 1;

        left->parent = newRoot;
        right->parent = newRoot;
        mgmt->root = newRoot;
        mgmt->numNodes++;

        return RC_OK;
    }

    BTreeNode *parent = left->parent;

    // Find insertion position in parent
    int insertPos = 0;
    while (insertPos < parent->numKeys && parent->keys[insertPos] < key) {
        insertPos++;
    }

    // If parent has space
    if (parent->numKeys < mgmt->order) {
        // Shift keys and pointers
        for (int i = parent->numKeys; i > insertPos; i--) {
            parent->keys[i] = parent->keys[i - 1];
            parent->pointers[i + 1] = parent->pointers[i];
        }

        parent->keys[insertPos] = key;
        parent->pointers[insertPos + 1] = right;
        parent->numKeys++;
        right->parent = parent;

        return RC_OK;
    }

    // Parent is full, need to split
    // Create temporary array to hold all keys including the new one
    int tempKeys[mgmt->order + 1];
    BTreeNode *tempPointers[mgmt->order + 2];

    // Copy existing keys and pointers, inserting new key in correct position
    int j = 0;
    for (int i = 0; i <= parent->numKeys; i++) {
        if (i == insertPos) {
            tempKeys[i] = key;
            tempPointers[i + 1] = right;
        } else {
            tempKeys[i] = parent->keys[j];
            tempPointers[i + 1] = parent->pointers[j + 1];
            j++;
        }
    }
    tempPointers[0] = parent->pointers[0];

    // Create new internal node
    BTreeNode *newParent = createNode(mgmt->order, NT_INTERNAL);

    // Split according to B+tree rules for internal nodes
    int splitPoint = mgmt->order / 2;
    int promotedKey = tempKeys[splitPoint];

    // Left node (original parent) gets keys 0 to splitPoint-1
    parent->numKeys = splitPoint;
    for (int i = 0; i < splitPoint; i++) {
        parent->keys[i] = tempKeys[i];
        parent->pointers[i] = tempPointers[i];
        if (parent->pointers[i] != NULL) {
            ((BTreeNode *) parent->pointers[i])->parent = parent;
        }
    }
    parent->pointers[splitPoint] = tempPointers[splitPoint];
    if (parent->pointers[splitPoint] != NULL) {
        ((BTreeNode *) parent->pointers[splitPoint])->parent = parent;
    }

    // Right node gets keys splitPoint+1 to order
    newParent->numKeys = mgmt->order - splitPoint;
    for (int i = 0; i < newParent->numKeys; i++) {
        newParent->keys[i] = tempKeys[splitPoint + 1 + i];
        newParent->pointers[i] = tempPointers[splitPoint + 1 + i];
        if (newParent->pointers[i] != NULL) {
            ((BTreeNode *) newParent->pointers[i])->parent = newParent;
        }
    }
    newParent->pointers[newParent->numKeys] = tempPointers[mgmt->order + 1];
    if (newParent->pointers[newParent->numKeys] != NULL) {
        ((BTreeNode *) newParent->pointers[newParent->numKeys])->parent = newParent;
    }

    newParent->parent = parent->parent;
    mgmt->numNodes++;

    return insertIntoParent(mgmt, parent, promotedKey, newParent);
}



static RC deleteFromLeaf(BTreeMgmtData *mgmt, BTreeNode *leaf, int key) {
    // Find key position
    int keyPos = -1;
    for (int i = 0; i < leaf->numKeys; i++) {
        if (leaf->keys[i] == key) {
            keyPos = i;
            break;
        }
    }

    if (keyPos == -1) {
        return RC_IM_KEY_NOT_FOUND;
    }

    // Free the RID pointer
    free(leaf->pointers[keyPos]);

    // Shift keys and pointers
    for (int i = keyPos; i < leaf->numKeys - 1; i++) {
        leaf->keys[i] = leaf->keys[i + 1];
        leaf->pointers[i] = leaf->pointers[i + 1];
    }

    leaf->numKeys--;

    // Check if underflow occurred
    int minKeys = (mgmt->order + 1) / 2;
    if (leaf->numKeys >= minKeys || leaf->parent == NULL) {
        return RC_OK; // No underflow or root node
    }

    // Handle underflow - simplified version
    return RC_OK;
}

// Debug function
char *printTree(BTreeHandle *tree) {
    if (tree == NULL || tree->mgmtData == NULL) {
        char *result = (char *) malloc(50);
        strcpy(result, "Tree is empty or not initialized");
        return result;
    }

    BTreeMgmtData *mgmt = (BTreeMgmtData *) tree->mgmtData;

    if (mgmt->root == NULL) {
        char *result = (char *) malloc(20);
        strcpy(result, "Empty tree");
        return result;
    }

    int nodeCounter = 0;
    return serializeTree(mgmt->root, &nodeCounter);
}

static char *serializeTree(BTreeNode *root, int *nodeCounter) {
    if (root == NULL) {
        char *result = (char *) malloc(20);
        strcpy(result, "Empty tree");
        return result;
    }

    // Allocate large buffer for result
    char *result = (char *) malloc(10000);
    result[0] = '\0';

    // Reset counter and serialize in depth-first pre-order
    *nodeCounter = 0;
    serializeNode(root, result, *nodeCounter, nodeCounter);

    return result;
}

static void serializeNode(BTreeNode *node, char *result, int nodeId, int *nodeCounter) {
    if (node == NULL) return;

    char nodeStr[1000];

    if (node->nodeType == NT_LEAF) {
        // Format: (nodeId)[rid,key,rid,key,...]
        sprintf(nodeStr, "(%d)[", nodeId);

        for (int i = 0; i < node->numKeys; i++) {
            if (i > 0) {
                strcat(nodeStr, ",");
            }

            RID *rid = (RID *) node->pointers[i];
            char ridStr[50];
            sprintf(ridStr, "%d.%d,%d", rid->page, rid->slot, node->keys[i]);
            strcat(nodeStr, ridStr);
        }

        strcat(nodeStr, "]\n");
    } else {
        // Format: (nodeId)[pointer,key,pointer,key,...,pointer]
        sprintf(nodeStr, "(%d)[", nodeId);

        // Assign child IDs properly
        int childIds[10]; // Assume max 10 children
        for (int i = 0; i <= node->numKeys; i++) {
            (*nodeCounter)++;
            childIds[i] = *nodeCounter;
        }

        // First pointer
        sprintf(nodeStr + strlen(nodeStr), "%d", childIds[0]);

        // Keys and pointers
        for (int i = 0; i < node->numKeys; i++) {
            sprintf(nodeStr + strlen(nodeStr), ",%d,%d", node->keys[i], childIds[i + 1]);
        }

        strcat(nodeStr, "]\n");
    }

    strcat(result, nodeStr);

    // Recursively serialize children for internal nodes
    if (node->nodeType == NT_INTERNAL) {
        for (int i = 0; i <= node->numKeys; i++) {
            if (node->pointers[i] != NULL) {
                (*nodeCounter)++;
                serializeNode((BTreeNode *) node->pointers[i], result, *nodeCounter, nodeCounter);
            }
        }
    }
}

// Stub types for missing record manager types
typedef struct RM_ScanHandle {
    void *mgmtData;
} RM_ScanHandle;

typedef struct Expr {
    void *mgmtData;
} Expr;

// Stub functions for missing record manager functions
RC getAttr(Record *record, Schema *schema, int attrNum, Value **value) {
    // Stub implementation
    return RC_OK;
}

int getNumTuples(RM_TableData *rel) {
    // Stub implementation
    return 0;
}

RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond) {
    // Stub implementation
    return RC_OK;
}

RC next(RM_ScanHandle *scan, Record *record) {
    // Stub implementation
    return RC_RM_NO_MORE_TUPLES;
}

RC closeScan(RM_ScanHandle *scan) {
    // Stub implementation
    return RC_OK;
}