#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "dberror.h"

// Simple buffer pool implementation
typedef struct BufferFrame {
    PageNumber pageNum;
    char *data;
    bool dirty;
    int fixCount;
    int lastUsed;
} BufferFrame;

typedef struct BufferMgmtData {
    BufferFrame *frames;
    int numPages;
    int currentTime;
    SM_FileHandle fileHandle;
    int numReadIO;
    int numWriteIO;
} BufferMgmtData;

// Buffer Manager Interface Pool Handling
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName,
        const int numPages, ReplacementStrategy strategy, void *stratData) {

    // Open page file
    SM_FileHandle *fh = (SM_FileHandle *) malloc(sizeof(SM_FileHandle));
    RC result = openPageFile((char *) pageFileName, fh);
    if (result != RC_OK) {
        free(fh);
        return result;
    }

    // Initialize buffer pool
    bm->pageFile = (char *) malloc(strlen(pageFileName) + 1);
    strcpy(bm->pageFile, pageFileName);
    bm->numPages = numPages;
    bm->strategy = strategy;

    // Initialize management data
    BufferMgmtData *mgmt = (BufferMgmtData *) malloc(sizeof(BufferMgmtData));
    mgmt->frames = (BufferFrame *) malloc(numPages * sizeof(BufferFrame));
    mgmt->numPages = numPages;
    mgmt->currentTime = 0;
    mgmt->fileHandle = *fh;
    mgmt->numReadIO = 0;
    mgmt->numWriteIO = 0;

    // Initialize frames
    for (int i = 0; i < numPages; i++) {
        mgmt->frames[i].pageNum = NO_PAGE;
        mgmt->frames[i].data = (char *) malloc(PAGE_SIZE);
        mgmt->frames[i].dirty = false;
        mgmt->frames[i].fixCount = 0;
        mgmt->frames[i].lastUsed = 0;
    }

    bm->mgmtData = mgmt;
    free(fh);

    return RC_OK;
}

RC shutdownBufferPool(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;

    // Force flush all dirty pages
    forceFlushPool(bm);

    // Close file
    closePageFile(&mgmt->fileHandle);

    // Free frames
    for (int i = 0; i < mgmt->numPages; i++) {
        free(mgmt->frames[i].data);
    }
    free(mgmt->frames);
    free(mgmt);
    free(bm->pageFile);

    return RC_OK;
}

RC forceFlushPool(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;

    for (int i = 0; i < mgmt->numPages; i++) {
        if (mgmt->frames[i].dirty && mgmt->frames[i].fixCount == 0) {
            RC result = writeBlock(mgmt->frames[i].pageNum, &mgmt->fileHandle, mgmt->frames[i].data);
            if (result != RC_OK) {
                return result;
            }
            mgmt->frames[i].dirty = false;
            mgmt->numWriteIO++;
        }
    }

    return RC_OK;
}

// Buffer Manager Interface Access Pages
RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;

    // Check if page is already in buffer
    for (int i = 0; i < mgmt->numPages; i++) {
        if (mgmt->frames[i].pageNum == pageNum) {
            mgmt->frames[i].fixCount++;
            mgmt->frames[i].lastUsed = ++mgmt->currentTime;
            page->pageNum = pageNum;
            page->data = mgmt->frames[i].data;
            return RC_OK;
        }
    }

    // Find empty frame or replace
    int frameIndex = -1;
    for (int i = 0; i < mgmt->numPages; i++) {
        if (mgmt->frames[i].pageNum == NO_PAGE) {
            frameIndex = i;
            break;
        }
    }

    // If no empty frame, use FIFO replacement
    if (frameIndex == -1) {
        int oldestTime = mgmt->currentTime + 1;
        for (int i = 0; i < mgmt->numPages; i++) {
            if (mgmt->frames[i].fixCount == 0 && mgmt->frames[i].lastUsed < oldestTime) {
                oldestTime = mgmt->frames[i].lastUsed;
                frameIndex = i;
            }
        }
    }

    if (frameIndex == -1) {
        return RC_WRITE_FAILED; // No available frame
    }

    // Write dirty page back if needed
    if (mgmt->frames[frameIndex].dirty) {
        RC result = writeBlock(mgmt->frames[frameIndex].pageNum, &mgmt->fileHandle, mgmt->frames[frameIndex].data);
        if (result != RC_OK) {
            return result;
        }
        mgmt->numWriteIO++;
    }

    // Read new page
    RC result = readBlock(pageNum, &mgmt->fileHandle, mgmt->frames[frameIndex].data);
    if (result != RC_OK) {
        return result;
    }
    mgmt->numReadIO++;

    // Update frame
    mgmt->frames[frameIndex].pageNum = pageNum;
    mgmt->frames[frameIndex].dirty = false;
    mgmt->frames[frameIndex].fixCount = 1;
    mgmt->frames[frameIndex].lastUsed = ++mgmt->currentTime;

    page->pageNum = pageNum;
    page->data = mgmt->frames[frameIndex].data;

    return RC_OK;
}

RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;

    // Find the frame containing this page
    for (int i = 0; i < mgmt->numPages; i++) {
        if (mgmt->frames[i].pageNum == page->pageNum && mgmt->frames[i].data == page->data) {
            mgmt->frames[i].dirty = true;
            return RC_OK;
        }
    }

    return RC_FILE_HANDLE_NOT_INIT;
}

RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;

    // Find the frame containing this page
    for (int i = 0; i < mgmt->numPages; i++) {
        if (mgmt->frames[i].pageNum == page->pageNum && mgmt->frames[i].data == page->data) {
            if (mgmt->frames[i].fixCount > 0) {
                mgmt->frames[i].fixCount--;
            }
            return RC_OK;
        }
    }

    return RC_FILE_HANDLE_NOT_INIT;
}

RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;

    // Find the frame containing this page
    for (int i = 0; i < mgmt->numPages; i++) {
        if (mgmt->frames[i].pageNum == page->pageNum && mgmt->frames[i].data == page->data) {
            if (mgmt->frames[i].dirty) {
                RC result = writeBlock(mgmt->frames[i].pageNum, &mgmt->fileHandle, mgmt->frames[i].data);
                if (result != RC_OK) {
                    return result;
                }
                mgmt->frames[i].dirty = false;
                mgmt->numWriteIO++;
            }
            return RC_OK;
        }
    }

    return RC_FILE_HANDLE_NOT_INIT;
}

// Statistics Interface
PageNumber *getFrameContents(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return NULL;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;
    PageNumber *frameContents = (PageNumber *) malloc(mgmt->numPages * sizeof(PageNumber));

    for (int i = 0; i < mgmt->numPages; i++) {
        frameContents[i] = mgmt->frames[i].pageNum;
    }

    return frameContents;
}

bool *getDirtyFlags(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return NULL;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;
    bool *dirtyFlags = (bool *) malloc(mgmt->numPages * sizeof(bool));

    for (int i = 0; i < mgmt->numPages; i++) {
        dirtyFlags[i] = mgmt->frames[i].dirty;
    }

    return dirtyFlags;
}

int *getFixCounts(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return NULL;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;
    int *fixCounts = (int *) malloc(mgmt->numPages * sizeof(int));

    for (int i = 0; i < mgmt->numPages; i++) {
        fixCounts[i] = mgmt->frames[i].fixCount;
    }

    return fixCounts;
}

int getNumReadIO(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return 0;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;
    return mgmt->numReadIO;
}

int getNumWriteIO(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL) {
        return 0;
    }

    BufferMgmtData *mgmt = (BufferMgmtData *) bm->mgmtData;
    return mgmt->numWriteIO;
}