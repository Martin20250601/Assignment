#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "storage_mgr.h"
#include "dberror.h"

void initStorageManager(void) {
    // Initialize storage manager
}

RC createPageFile(char *fileName) {
    FILE *file = fopen(fileName, "wb");
    if (file == NULL) {
        return RC_FILE_NOT_FOUND;
    }

    // Create empty page
    char *emptyPage = (char *) calloc(PAGE_SIZE, sizeof(char));
    fwrite(emptyPage, sizeof(char), PAGE_SIZE, file);

    free(emptyPage);
    fclose(file);
    return RC_OK;
}

RC openPageFile(char *fileName, SM_FileHandle *fHandle) {
    FILE *file = fopen(fileName, "rb+");
    if (file == NULL) {
        return RC_FILE_NOT_FOUND;
    }

    fHandle->fileName = (char *) malloc(strlen(fileName) + 1);
    strcpy(fHandle->fileName, fileName);
    fHandle->mgmtInfo = file;
    fHandle->curPagePos = 0;

    // Get total number of pages
    fseek(file, 0, SEEK_END);
    fHandle->totalNumPages = ftell(file) / PAGE_SIZE;
    fseek(file, 0, SEEK_SET);

    return RC_OK;
}

RC closePageFile(SM_FileHandle *fHandle) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    fclose((FILE *) fHandle->mgmtInfo);
    free(fHandle->fileName);
    fHandle->mgmtInfo = NULL;

    return RC_OK;
}

RC destroyPageFile(char *fileName) {
    if (remove(fileName) != 0) {
        return RC_FILE_NOT_FOUND;
    }
    return RC_OK;
}

RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    if (pageNum < 0 || pageNum >= fHandle->totalNumPages) {
        return RC_READ_NON_EXISTING_PAGE;
    }

    FILE *file = (FILE *) fHandle->mgmtInfo;
    fseek(file, pageNum * PAGE_SIZE, SEEK_SET);

    if (fread(memPage, sizeof(char), PAGE_SIZE, file) < PAGE_SIZE) {
        return RC_READ_NON_EXISTING_PAGE;
    }

    fHandle->curPagePos = pageNum;
    return RC_OK;
}

int getBlockPos(SM_FileHandle *fHandle) {
    if (fHandle == NULL) {
        return -1;
    }
    return fHandle->curPagePos;
}

RC readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    return readBlock(0, fHandle, memPage);
}

RC readPreviousBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    return readBlock(fHandle->curPagePos - 1, fHandle, memPage);
}

RC readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    return readBlock(fHandle->curPagePos, fHandle, memPage);
}

RC readNextBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    return readBlock(fHandle->curPagePos + 1, fHandle, memPage);
}

RC readLastBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    return readBlock(fHandle->totalNumPages - 1, fHandle, memPage);
}

RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    if (pageNum < 0) {
        return RC_WRITE_FAILED;
    }

    FILE *file = (FILE *) fHandle->mgmtInfo;

    // Extend file if necessary
    if (pageNum >= fHandle->totalNumPages) {
        ensureCapacity(pageNum + 1, fHandle);
    }

    fseek(file, pageNum * PAGE_SIZE, SEEK_SET);

    if (fwrite(memPage, sizeof(char), PAGE_SIZE, file) < PAGE_SIZE) {
        return RC_WRITE_FAILED;
    }

    fHandle->curPagePos = pageNum;
    fflush(file);
    return RC_OK;
}

RC writeCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    return writeBlock(fHandle->curPagePos, fHandle, memPage);
}

RC appendEmptyBlock(SM_FileHandle *fHandle) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    char *emptyPage = (char *) calloc(PAGE_SIZE, sizeof(char));
    RC result = writeBlock(fHandle->totalNumPages, fHandle, emptyPage);

    free(emptyPage);
    return result;
}

RC ensureCapacity(int numberOfPages, SM_FileHandle *fHandle) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    while (fHandle->totalNumPages < numberOfPages) {
        RC result = appendEmptyBlock(fHandle);
        if (result != RC_OK) {
            return result;
        }
        fHandle->totalNumPages++;
    }

    return RC_OK;
}