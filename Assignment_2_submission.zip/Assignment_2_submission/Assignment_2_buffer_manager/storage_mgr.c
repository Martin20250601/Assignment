#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "storage_mgr.h"
#include "dberror.h"

void initStorageManager(void) {
    printf("Storage manager initialized.\n");
}

RC createPageFile(char *fileName) {
    FILE *file = fopen(fileName, "wb");
    if (file == NULL)
        return RC_FILE_NOT_FOUND;

    // Create an empty page filled with '\0' bytes
    char *emptyPage = calloc(PAGE_SIZE, sizeof(char));
    if (emptyPage == NULL) {
        fclose(file);
        return RC_WRITE_FAILED;
    }

    // Write the empty page to the file
    if (fwrite(emptyPage, sizeof(char), PAGE_SIZE, file) != PAGE_SIZE) {
        free(emptyPage);
        fclose(file);
        return RC_WRITE_FAILED;
    }

    free(emptyPage);
    fclose(file);
    return RC_OK;
}

RC openPageFile(char *fileName, SM_FileHandle *fHandle) {
    FILE *file = fopen(fileName, "r+b");
    if (file == NULL)
        return RC_FILE_NOT_FOUND;

    // Get the total number of pages
    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    int totalNumPages = fileSize / PAGE_SIZE;

    // Initialize file handle
    fHandle->fileName = fileName;
    fHandle->totalNumPages = totalNumPages;
    fHandle->curPagePos = 0;
    fHandle->mgmtInfo = file;

    return RC_OK;
}

RC closePageFile(SM_FileHandle *fHandle) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    FILE *file = (FILE *)fHandle->mgmtInfo;
    fclose(file);
    fHandle->mgmtInfo = NULL;

    return RC_OK;
}

RC destroyPageFile(char *fileName) {
    if (remove(fileName) != 0)
        return RC_FILE_NOT_FOUND;
    return RC_OK;
}

RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    if (pageNum < 0 || pageNum >= fHandle->totalNumPages)
        return RC_READ_NON_EXISTING_PAGE;

    FILE *file = (FILE *)fHandle->mgmtInfo;
    if (fseek(file, pageNum * PAGE_SIZE, SEEK_SET) != 0)
        return RC_READ_NON_EXISTING_PAGE;

    if (fread(memPage, sizeof(char), PAGE_SIZE, file) != PAGE_SIZE)
        return RC_READ_NON_EXISTING_PAGE;

    fHandle->curPagePos = pageNum;
    return RC_OK;
}

int getBlockPos(SM_FileHandle *fHandle) {
    if (fHandle == NULL)
        return -1;
    return fHandle->curPagePos;
}

RC readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    return readBlock(0, fHandle, memPage);
}

RC readPreviousBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL)
        return RC_FILE_HANDLE_NOT_INIT;
    return readBlock(fHandle->curPagePos - 1, fHandle, memPage);
}

RC readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL)
        return RC_FILE_HANDLE_NOT_INIT;
    return readBlock(fHandle->curPagePos, fHandle, memPage);
}

RC readNextBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL)
        return RC_FILE_HANDLE_NOT_INIT;
    return readBlock(fHandle->curPagePos + 1, fHandle, memPage);
}

RC readLastBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL)
        return RC_FILE_HANDLE_NOT_INIT;
    return readBlock(fHandle->totalNumPages - 1, fHandle, memPage);
}

RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    if (pageNum < 0 || pageNum >= fHandle->totalNumPages)
        return RC_WRITE_FAILED;

    FILE *file = (FILE *)fHandle->mgmtInfo;
    if (fseek(file, pageNum * PAGE_SIZE, SEEK_SET) != 0)
        return RC_WRITE_FAILED;

    if (fwrite(memPage, sizeof(char), PAGE_SIZE, file) != PAGE_SIZE)
        return RC_WRITE_FAILED;

    fHandle->curPagePos = pageNum;
    return RC_OK;
}

RC writeCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    if (fHandle == NULL)
        return RC_FILE_HANDLE_NOT_INIT;
    return writeBlock(fHandle->curPagePos, fHandle, memPage);
}

RC appendEmptyBlock(SM_FileHandle *fHandle) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    FILE *file = (FILE *)fHandle->mgmtInfo;
    if (fseek(file, 0, SEEK_END) != 0)
        return RC_WRITE_FAILED;

    char *emptyPage = calloc(PAGE_SIZE, sizeof(char));
    if (emptyPage == NULL)
        return RC_WRITE_FAILED;

    if (fwrite(emptyPage, sizeof(char), PAGE_SIZE, file) != PAGE_SIZE) {
        free(emptyPage);
        return RC_WRITE_FAILED;
    }

    free(emptyPage);
    fHandle->totalNumPages++;
    return RC_OK;
}

RC ensureCapacity(int numberOfPages, SM_FileHandle *fHandle) {
    if (fHandle == NULL || fHandle->mgmtInfo == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    if (fHandle->totalNumPages >= numberOfPages)
        return RC_OK;

    int pagesToAppend = numberOfPages - fHandle->totalNumPages;
    for (int i = 0; i < pagesToAppend; i++) {
        RC result = appendEmptyBlock(fHandle);
        if (result != RC_OK)
            return result;
    }

    return RC_OK;
} 